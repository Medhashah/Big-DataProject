
import os
import time
import re
import operator
import json

test_dict = {}
test_dict["predicted_types"] = []

actual_dict_1 = {}
actual_dict_1["actual_types"] = []


# Reads in actual semantic types for each file
actual_dict = {}
actual = open("actual.txt", "r")
actual = actual.read().split("\n")
for x in actual[:-1]:
    actual_dict[x.split(", ", 1)[0]] = x.split(", ", 1)[1]

# Variable initialization
good_count = 0
bad_count = 0
total_multi_count = 0
total_single_count = 0
multi_good = 0
single_good = 0
multi_bad = 0
single_bad = 0
test = open("test.txt", "w+")
start = time.time()
file_list = []

# Iterates over all files in data set
for filename in os.listdir("columns"):
    # Vote dictionary initialization, each vote for a given type is logged here for each file
    name = filename.split(".")
    vote_dictionary = {}
    vote_dictionary["first_name"] = 0
    vote_dictionary["last_name"] = 0
    vote_dictionary["full_name"] = 0
    vote_dictionary["business"] = 0
    vote_dictionary["phone_number"] = 0
    vote_dictionary["address"] = 0
    vote_dictionary["street"] = 0
    vote_dictionary["city"] = 0
    vote_dictionary["neighborhood"] = 0
    vote_dictionary["coordinate"] = 0
    vote_dictionary["zip"] = 0
    vote_dictionary["borough"] = 0
    vote_dictionary["school_name"] = 0
    vote_dictionary["color"] = 0
    vote_dictionary["vehicle_make"] = 0
    vote_dictionary["agency"] = 0
    vote_dictionary["study_area"] = 0
    vote_dictionary["school_subject"] = 0
    vote_dictionary["school_level"] = 0
    vote_dictionary["college"] = 0
    vote_dictionary["website"] = 0
    vote_dictionary["building_class"] = 0
    vote_dictionary["vehicle_type"] = 0
    vote_dictionary["location"] = 0
    vote_dictionary["park"] = 0
    text_count = 0
    f = open("columns/" + filename, "r", encoding="utf8")
    text = f.read()
    text = text.split("\n")

    # Attempts to get a type vote from every line in file
    marked_lines = []
    for x in text:
        mark_flag = 0
        # Gets number of lines containing alphabetical characters, used for type discrimination
        if x.split("\t")[0].isalpha() == 1:
            text_count += 1

        ## BEGIN CLASSIFICATION

        #coordinates
        p = re.compile('\([0-9]*\.[0-9]*, ')
        if p.match(x.split("\t")[0]):
            vote_dictionary["coordinate"] = vote_dictionary["coordinate"] + 1
            marked_lines.append("coordinate\t" + x)
            mark_flag = 1

        #Phone Number
        p = re.compile('\([0-9]*\)')
        q = re.compile('[0-9]{3}-[0-9][0-9][0-9]-')
        r = re.compile('[0-9]{10,10}\t')
        s = re.compile('[0-9]{3} [0-9]{3} [0-9]{4}')
        if p.match(x.split("\t")[0]) or q.match(x.split("\t")[0]) or r.match(x) or s.match(x.split("\t")[0]):
            vote_dictionary["phone_number"] = vote_dictionary["phone_number"] + 1
            marked_lines.append("phone_number\t" + x)
            mark_flag = 1

        #ZIP Codes
        p = re.compile('[0-9]{5}\t')
        q = re.compile('[0-9]{5}-[0-9]{4}')
        if p.match(x) or q.match(x.split("\t")[0]):
            vote_dictionary["zip"] = vote_dictionary["zip"] + 1
            marked_lines.append("zip\t" + x)
            mark_flag = 1

        #Street Names
        street_flag = 0
        street = ["avenue", "street", "drive", "road", "terrace", "expressway", "parkway", "place", "lane", "boulevard", "driveway"]
        for l in street:
            if l in x.split("\t")[0].lower():
                p = re.compile('[0-9]*[a-z]* [a-z]*\t')
                q = re.compile('playground')
                if p.match(x.lower()) and not q.match(x.lower()):
                    vote_dictionary["street"] = vote_dictionary["street"] + 1
                    street_flag = 1
                    marked_lines.append("street\t" + x)
                    mark_flag = 1
        #Address
        for l in street:
            if l in x.split("\t")[0].lower():
                p = re.compile('[0-9]* [0-9]*[a-z]* [a-z]*')
                q = re.compile('playground')
                if p.match(x.split("\t")[0].lower()) and not q.match(x.lower()):
                    vote_dictionary["address"] = vote_dictionary["address"] + 1
                    street_flag = 1
                    marked_lines.append("address\t" + x)
                    mark_flag = 1
        #Business Types
        business = ["llc", "inc.", "p.c.", "cafe", "deli", "grocery", "pllc", "llp", "architects"]
        business_flag = 0
        for y in business:
            if y in x.split("\t")[0].lower() and street_flag == 0:
                business_flag = 1
                vote_dictionary["business"] = vote_dictionary["business"] + 1
                marked_lines.append("business\t" + x)
                mark_flag = 1
        #Websites
        web_flag = 0
        sites = [".com", ".org", ".net", ".edu", ".nyc"]
        for l in sites:
            if l in x.split("\t")[0].lower():
                vote_dictionary["website"] = vote_dictionary["website"] + 1
                web_flag = 1
                marked_lines.append("website\t" + x)
                mark_flag = 1
        #Playground
        park = ["playground"]
        bad = ["parkplace", "parkway"]
        for l in park:
            if l in x.split("\t")[0].lower():
                for y in bad:
                    if y not in x.split("\t")[0].lower():
                        vote_dictionary["park"] = vote_dictionary["park"] + 1
                        marked_lines.append("park\t" + x)
                        mark_flag = 1
        #University
        uni = ["university of", "college of"]
        for l in uni:
            if (l in x.split("\t")[0].lower()) and (street_flag == 0) and (web_flag == 0):
                if not re.search('\d', x.split("\t")[0].lower()) and "school" not in x.lower():
                    vote_dictionary["college"] = vote_dictionary["college"] + 1
                    marked_lines.append("college\t" + x)
                    mark_flag = 1
        #School Level
        level = ["k-8\t", "high school\t", "middle school\t", "elementary school"]
        for l in level:
            if l in x.lower() and x.split("\t")[0].count(' ') <= 1:
                vote_dictionary["school_level"] = vote_dictionary["school_level"] + 1
                marked_lines.append("school_level\t" + x)
                mark_flag = 1
        #Schools
        school = ["school", "academy"]
        for l in school:
            if l in x.split("\t")[0].lower() and street_flag == 0 and web_flag == 0 and x.split("\t")[0].count(' ') >= 2:
                vote_dictionary["school_name"] = vote_dictionary["school_name"] + 1
                marked_lines.append("school_name\t" + x)
                mark_flag = 1
        #Color
        color = ["red\t", "green\t", "blue\t", "yellow\t", "purple\t", "pink\t", "white\t"]
        for l in color:
            if x.lower().startswith(l) and x.split("\t")[0].count(' ') == 0:
                vote_dictionary["color"] = vote_dictionary["color"] + 1
                marked_lines.append("color\t" + x)
                mark_flag = 1
        #Car Make
        car = ["toyota\t", "ford\t", "toyot\t", "audi\t", "4dsd\t", "4s\t", "4w\t", "CN\t"]
        for l in car:
            if x.lower().startswith(l) and x.split("\t")[0].count(' ') == 0:
                vote_dictionary["vehicle_make"] = vote_dictionary["vehicle_make"] + 1
                marked_lines.append("vehicle_make\t" + x)
                mark_flag = 1
        #Vehicle Type
        v_type = ["motorcycle\t", "fire truck\t", "ambulance\t", "armored truck\t", "bus\t"]
        for l in v_type:
            if x.lower().startswith(l):
                vote_dictionary["vehicle_type"] = vote_dictionary["vehicle_type"] + 1
                marked_lines.append("vehicle_type\t" + x)
                mark_flag = 1
        #Building classification
        b_type = ["walk-up\t", "elevator\t", "condops\t"]
        for l in b_type:
            if l in x.lower():
                vote_dictionary["building_class"] = vote_dictionary["building_class"] + 1
                marked_lines.append("building_class\t" + x)
                mark_flag = 1
        #Agencies
        b_type = ["NYPD\t", "DHS\t", "DFTA\t", "DOITT\t", "DEPARTMENT OF", "HHC", "OFFICE OF"]
        for l in b_type:
            if x.upper().startswith(l):
                vote_dictionary["agency"] = vote_dictionary["agency"] + 1
                marked_lines.append("agency\t" + x)
                mark_flag = 1
        #Location type
        l_type = ["bank\t", "airport terminal\t", "construction site\t", "church\t", "gas station\t"]
        for l in l_type:
            if x.lower().startswith(l):
                vote_dictionary["location"] = vote_dictionary["location"] + 1
                marked_lines.append("location\t" + x)
                mark_flag = 1
        #Areas of Study
        s_areas = ["teaching\t", "architecture\t", "humanities\t", "humanities & ", "art\t" "engineering\t", "science\t", "science & math\t", "math\t"]
        for l in s_areas:
            if x.lower().startswith(l) and "school" not in x.lower():
                vote_dictionary["study_area"] = vote_dictionary["study_area"] + 1
                marked_lines.append("study_area\t" + x)
                mark_flag = 1
        #Specific courses
        classes = ["math a\t", "physics\t", "english 10\t", "geometry\t", "algebra\t"]
        for l in classes:
            if x.lower().startswith(l) and "school" not in x.lower():
                vote_dictionary["school_subject"] = vote_dictionary["school_subject"] + 1
                marked_lines.append("school_subject\t" + x)
                mark_flag = 1
        #Boroughs
        boroughs = ["bronx\t", "brooklyn\t", "manhattan\t", "queens\t", "staten island\t"]
        for l in boroughs:
            if x.lower().startswith(l) and "school" not in x.lower():
                vote_dictionary["borough"] = vote_dictionary["borough"] + 1
                marked_lines.append("borough\t" + x)
                mark_flag = 1
        #Neighborhood
        n_hood = ["port richmond\t", "south jamaica\t", "bronxdale\t", "bushwick\t", "canarsie\t", "dumbo\t", "east midtown\t", "jamaica\t", "flushing\t", "upper east side\t", "silver lake\t", "sunnyside\t", "rosebank\t", "woodside\t", "woodhaven\t", "middle village\t", "hill crest\t", "forest_hills\t"]
        for l in n_hood:
            if x.lower().startswith(l) and "school" not in x.lower():
                vote_dictionary["neighborhood"] = vote_dictionary["neighborhood"] + 1
                marked_lines.append("neighborhood\t" + x)
                mark_flag = 1
        #Cities
        cities = ["austin\t", "des moines\t",  "hicksville\t", "philadelphia\t", "phoenix\t", "chicago\t", "las angeles\t", "columbus\t", "east elmhurst\t", "far rock\t", "farmingdale\t"]
        for l in cities:
            if x.lower().startswith(l) and "school" not in x.lower():
                vote_dictionary["city"] = vote_dictionary["city"] + 1
                marked_lines.append("city\t" + x)
                mark_flag = 1
        #First Names
        f_name = ["emma\t", "olivia\t", "sophia\t", "isabella\t", "charlotte\t", "ameila\t", "harper\t", "evelyn\t", "avery\t", "elizabeth\t", "abigail\t", "emily\t" , "noah\t", "oliver\t", "benjamin\t", "jacob\t", "alexander\t", "ethan\t", "brian\t", "aiden\t", "henry\t"]
        for l in f_name:
             if l in x.lower() and street_flag == 0 and web_flag == 0 and x.split("\t")[0].count(' ') == 0:
                p = re.compile('[0-9]')
                if not p.match(x.split("\t")[0]):
                    vote_dictionary["first_name"] = vote_dictionary["first_name"] + 1
                    marked_lines.append("first_name\t" + x)
                    mark_flag = 1
        #Last Names
        f_name = ["smith\t", "johnson\t", "williams\t", "brown\t", "jones\t", "miller\t", "davis\t", "garcia\t", "rodriguez\t", "wilson\t", "martinez\t", "anderson\t", "moore\t"]
        for l in f_name:
             if l in x.lower() and street_flag == 0 and web_flag == 0 and x.split("\t")[0].count(' ') == 0:
                p = re.compile('[0-9]')
                if not p.match(x.split("\t")[0]):
                    vote_dictionary["last_name"] = vote_dictionary["last_name"] + 1
                    marked_lines.append("last_name\t" + x)
                    mark_flag = 1
        #Full name
        f_name = ["smith", "johnson", "williams", "brown", "jones", "miller", "davis", "garcia", "rodriguez", "wilson", "martinez", "anderson", "moore"]
        for l in f_name:
             if l in x.lower() and street_flag == 0 and web_flag == 0 and business_flag == 0 and x.split("\t")[0].count(', ') == 1:
                p = re.compile('[0-9]')
                if not p.match(x.split("\t")[0]):
                    vote_dictionary["full_name"] = vote_dictionary["full_name"] + 1
                    marked_lines.append("full_name\t" + x)
                    mark_flag = 1

        # Marks a line as no discernible type if no type has been confidently given
        if mark_flag == 0:
            if len(("no mark\t" + x).split("\t")) == 3:
                marked_lines.append("no mark\t" + x)
    if text_count > len(text) * 0.2:
        vote_dictionary["zip"] = 0

    ## Multiple Class Detection
    vote_dictionary_hold = vote_dictionary.copy()
    first_flag = 1
    top_v = []
    for y in vote_dictionary_hold.items():
        current_item = max(vote_dictionary.items(), key=operator.itemgetter(1))[0]
        if vote_dictionary[current_item] == 0 and first_flag == 1: #Top vote has 0 votes
            del vote_dictionary[current_item]
            top_v.append("other")
            first_flag = 0
            max_vote = "other"
            break

        elif vote_dictionary[current_item] > 0 and first_flag == 1: #Top vote has >0 votes
            top_v.append(current_item)
            del vote_dictionary[current_item]
            first_flag = 0
            top_vote_amount = vote_dictionary_hold[current_item]
            max_vote = current_item

        # Checks number of votes in non-top categories in relation to top vote
        elif vote_dictionary[current_item] > (top_vote_amount*0.70) and first_flag == 0: #Nontop vote has greater than threshold votes
            top_v.append(current_item)
            del vote_dictionary[current_item]

        elif vote_dictionary[current_item] == 0 and first_flag == 0: #Next item has 0 votes
            break
        else:
            continue
    top_v.sort()
    actual_list = actual_dict[filename].split(", ")
    cat_list = ""
    for x in top_v:
        if not cat_list:
            cat_list = str(x)
        else:
            cat_list = cat_list + ", " + str(x)

    # Outputs classification to file
    test.write(filename + ", " + cat_list + "\n")

    # Counts number of occurrences of each semantic type
    # In the case of multiple types detected by classifier unclassified lines are defaulted to top vote class
    count_dict = {}
    for x in marked_lines:
        if x.split("\t")[0] in cat_list:
            if x.split("\t")[0] not in count_dict:
                count_dict[x.split("\t")[0]] = int(x.split("\t")[2])
            else:
                count_dict[x.split("\t")[0]] += int(x.split("\t")[2])
        else:
            if max_vote not in count_dict:
                count_dict[max_vote] = int(x.split("\t")[2])
            else:
                count_dict[max_vote] += int(x.split("\t")[2])

    #JSON Builder

    test_dict_1 = {}
    test_dict_1["column_name"] = filename
    test_dict_1["semantic_types"] = []
    for p in count_dict:
        test_dict_1["semantic_types"].append({"semantic_type": p, "count": count_dict[p]})
    test_dict["predicted_types"].append(test_dict_1)


    actual_dict_2 = {}
    actual_dict_2["column_name"] = filename
    actual_dict_2["manual_labels"] = []
    for p in actual_dict[filename].split(", "):
        actual_dict_2["manual_labels"].append(p)
    actual_dict_1["actual_types"].append(actual_dict_2)

end = time.time()
with open('task2.json', 'w') as outfile:
    json.dump(test_dict, outfile, indent=1)

with open('task2-manual-labels.json', 'w') as outfile:
    json.dump(actual_dict_1, outfile, indent=1)

print()
print("Run Time (seconds)")
print(end-start)