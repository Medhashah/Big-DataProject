
import matplotlib
import matplotlib.pyplot as plt

test = open("test.txt", "r")
actual = open("actual.txt", "r")

actual_dict = {}
test_dict = {}

# Acquires dictionaries linking each file to its predicted and actual classifications
actual = actual.read().split("\n")
for x in actual[:-1]:
    actual_dict[x.split(", ", 1)[0]] = x.split(", ", 1)[1]

test = test.read().split("\n")
for x in test[:-1]:
    test_dict[x.split(", ", 1)[0]] = x.split(", ", 1)[1]

# Creates dictionaries linking each semantic type to the number of correct predictions, incorrect predictions, and actual type occurances
incorrect_dict = {}
correct_dict = {}
occurrence_dict = {}
good = 0
bad = 0
for x in test_dict:
    if test_dict[x] == actual_dict[x]:
        good += 1
        if test_dict[x] not in correct_dict:
            correct_dict[test_dict[x]] = 1
        else:
            correct_dict[test_dict[x]] += 1
    else:
        bad += 1
        if test_dict[x] not in incorrect_dict:
            incorrect_dict[test_dict[x]] = 1
        else:
            incorrect_dict[test_dict[x]] += 1
    if actual_dict[x] not in occurrence_dict:
        occurrence_dict[actual_dict[x]] = 1
    else:
        occurrence_dict[actual_dict[x]] += 1

# Fills in type instances which did not occur in the incorrect dictionary with zeros (used for calculations later)
for x in correct_dict:
    if x not in incorrect_dict:
        incorrect_dict[x] = 0

# Calculates percission and recall for regex, dictionary, and combined approaches
regex_list = ["coordinate", "phone_number", "zip"]
regex_perc = 0
regex_recall = 0
dict_perc = 0
dict_recall = 0
total_perc = 0
total_recall = 0
for x in correct_dict:
    total = correct_dict[x] + incorrect_dict[x]
    perc = correct_dict[x] / total
    recall = correct_dict[x] / occurrence_dict[x]

    if x in regex_list:
        regex_perc += perc
        regex_recall += recall
    else:
        dict_perc += perc
        dict_recall += recall
    total_perc += perc
    total_recall += recall

total_perc = total_perc / len(correct_dict)
total_recall = total_recall / len(correct_dict)
dict_perc = dict_perc / (len(correct_dict) - len(regex_list))
dict_recall = dict_recall / (len(correct_dict) - len(regex_list))
regex_perc = regex_perc / len(regex_list)
regex_recall = regex_recall / len(regex_list)

# Outputs statistics
print("Total Stats:")
print(total_perc)
print(total_recall)
print()
print("Regex Stats")
print(regex_perc)
print(regex_recall)
print()
print("Dictionary Stats")
print(dict_perc)
print(dict_recall)
print()
print("Accuracy")
print(good/(good+bad))


# Gets number of single vs multi class columns, also converts multi types to add an occurance count to all classes it contains
multi = 0
single = 0
raw_count = {}
for x in occurrence_dict:
    if len(x.split(", ")) == 1:
        if x not in raw_count:
            raw_count[x] = occurrence_dict[x]
        else:
            raw_count[x] += occurrence_dict[x]
    else:
        for y in x.split(", "):
            if y not in raw_count:
                raw_count[y] = occurrence_dict[x]
            else:
                raw_count[y] += occurrence_dict[x]


for x in occurrence_dict:
    if len(x.split(", ")) > 1:
        multi += occurrence_dict[x]
    else:
        single += occurrence_dict[x]
print()
print("Number of multiple type columns")
print(multi)
print("Number of single type columns")
print(single)
print(occurrence_dict)


# Graph code
n_bins = len(raw_count)
plt.bar(raw_count.keys(), raw_count.values(), 1.0, color='r', ec="black")
plt.xticks(rotation=45)
plt.tick_params(axis='both', which='major', labelsize=13)
plt.title('Occurrences of Semantic Types', fontsize=13)
plt.ylabel('Times Found in Data Column', fontsize = 13)
plt.tight_layout()
plt.show()

plt.bar(["Single Value", "Multi Value"], [single, multi], 1.0, color='g', ec="black")
plt.tick_params(axis='both', which='major', labelsize=13)
plt.title('Heterogeneous vs Homogeneous Column Occurrence', fontsize=13)
plt.ylabel('# of Columns of Type', fontsize=13)
plt.tight_layout()
plt.show()