# -*- coding: utf-8 -*-
"""
Created on Tue Dec 10 20:51:53 2019

@author: johny
"""

import glob
import json

all_types = {}

read_files = glob.glob("*.json")

for f in read_files[:219]:
    with open(f, 'r', encoding='utf') as g:
        #counter+=1
        #if counter == 220:
        #    break
        test = json.load(g)
        test = test[1]
        out = test['semantic_types']
        types = []
        for dictionary in out:
            if dictionary['semantic_type'] == None:
                dictionary['semantic_type'] = 'other'
            types.append(dictionary['semantic_type'])
        all_types[f] = types

for f in read_files[220:]:
    with open(f, 'r', encoding='utf') as g:
        #counter+=1
        #if counter == 220:
        #    break
        test = json.load(g)
        test = test[1]
        out = test['semantic_types']
        types = []
        for dictionary in out:
            if dictionary['semantic_type'] == None:
                dictionary['semantic_type'] = 'other'
            types.append(dictionary['semantic_type'])
        all_types[f] = types
    #types[f] = test["semantic_type]

    
